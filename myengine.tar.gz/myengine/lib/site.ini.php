<?php

header('Content-Type: text/html; charset=utf-8');
ini_set('display_errors', 'on');


define('BASE_URL', 'http://185.4.73.209:7777/cartest.new/'); 
define('SITE_URL', 'cararac.com/');
define('SITE_DOMAIN', 'cararac.com');


// MVC_Directories.conf
define('DIR_INDEX', '../cartest/');
define('DIR_CONTROLLERS', '../controllers/');
define('DIR_TEMPLATES', '../templates/');
define('DIR_MODELS', '../models/');
define('DIR_LIBS', '../lib/');


// MYSQL
define("MYSQL_BASE", "test_new");
define("MYSQL_HOST", "localhost");
define("MYSQL_USER", "test_new_usr");
define("MYSQL_PASS", "RSYfy4bb6thz1nJi");
define('MYSQL_CHARSET', 'utf8');
define("MYSQL_PORT", 3306);

// REDIS
define("REDIS_HOST", "localhost");
define("REDIS_PORT", 6379);
define("REDIS_TTL", 60);


// tables
define("TN_MARKA", "marka");



// Pictures config
define('IMAGE_WIDTH', 400);
define('IMAGE_HEIGHT', 400);
define('IMAGE_SIZE', 512000);


// USER config
define("TN_USERS", "users");
define("TN_USER_TYPES", "user_types");
define("TN_USER_TYPE_ROLES", "user_type_roles");
define("TN_USER_ROLES", "user_roles");
define("TN_USER_ACCESS", "user_access");

// MAIL
define('ADMINISTRATION_MAIL', 'webmaster@cararac.com');

// Paginator conf
define('PGN_ADMIN', 50);