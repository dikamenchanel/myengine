<?php

namespace lib;


use controller\Admin\AdminController;

class Table
{
    public $titles  = [];
    public $data    = [];
    public $style   = [];
    public $filters = [];

    public function generateTable($SQLData)
    {
        $this->titles = array_keys($SQLData[0]);

        foreach($SQLData as $key => $value)
        {
            $this->data[$key] = array_values($value);
        }
    }

    public function addFilter($filter)
    {
        $this->filters[] = $filters;
    }

    public function addStyle($style)
    {
        $this->style = $style;
    }

    public function addAction($url)
    {
        $this->titles[] = 'actions';
        foreach( $this->data as $key => $value)
        {
            $this->data[$key]['urlAction'][] = "$url/edit/$value[0]";
            $this->data[$key]['urlAction'][] = "$url/delete/$value[0]";
        }
    }

    public function addLink($url, $inner='')
    {
        $this->titles[] = 'link';
        foreach( $this->data as $key => $value)
        {
            $this->data[$key]['urlLink']['href']      = $url;
            $this->data[$key]['urlLink']['innerHTML'] = $inner;
        }
    }

    public function changeDataRow($numRow, $dat1, $dat2)
    {
        foreach( $this->data as $key => $value)
        {
            if($value[$numRow] == $dat1[0])
            {
                $value[$numRow] = $dat1[1];
            }
            if($value[$numRow] == $dat2[0])
            {
                $value[$numRow] = $dat2[1];
            }

            $this->data[$key]  = $value;
        }
    }

    public function addInput($name, $numRow=0)
    {
        foreach($this->data as $key => $value)
        {
            $this->data[$key]['urlAction']['input']['name']    = $name;
            $this->data[$key]['urlAction']['input']['checked'] = (intval($this->data[$key][$numRow]) > 0) ? true : false;
        }
    }

}
