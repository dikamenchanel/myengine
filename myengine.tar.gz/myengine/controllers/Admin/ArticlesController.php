<?php

namespace controllers\Admin;

use controllers\Admin\AdminController;
use models\admin\ArticleModel;
use lib\Table;
use lib\Form;


class ArticlesController extends AdminController
{
    public $article;

    public function __construct()
    {
        parent::__construct();

        $this->article = new ArticleModel();

        // if($this->session->get('user_'.session_id())['role'] != 'Admin')
        // {
        //     return $this->view->redirect('admin');
        // }
    }


    function default($urlCategory, $i=0)
    {
        $url = $this->url.$urlCategory;

        $articles = $this->article->getDataArticles($i, 'DESC');

        $Table = new Table();

        $Table->generateTable($articles);

        $Table->addStyle([0 => 'width:10%;',1 => 'width:10%;', 3 => 'width:5%;justify-content:center;']);
        $Table->addLink("https://youtube.com");
        // $Table->addInput('change_repeat', 3);
        $Table->addAction($url);
        $Table->changeDataRow(3, [0, '-'], [1, '+']);

        $this->view->data['title']   = 'Article ';
        $this->view->data['Table']   = $Table;
        $this->view->data['Access']  = ($this->session->has('Access')) ? $this->session->get('Access') : false;
        $this->view->data['addIcon'] = "fa-solid fa-file-circle-plus fa-2xl";
        $this->view->data['addUrl']  = $url.'/add';

        $this->session->remove('Access');
        
        $countArticles = $this->article->getCountInfoArticles();

        if($countArticles > PGN_ADMIN )
        {
            $len = round($countArticles / PGN_ADMIN);
            $this->view->data['Pagination'] = array('url' => $url, 'active' => $i, 'len' => $len);
        }
    
        return $this->view->render('admin/index.html');
    }


    function addAction($urlCategory)
    {
        $Form = new Form();

        $Form->action = $this->url.$urlCategory.'/add';
        $Form->addSubmit('Сохранить', 'btn');
        $Form->addSelect('id_author', [1 => 'Dmitry Sapko', 2 => 'Mohamed Salah'], 'Автор статьи');
        $Form->addInput('ar_title', '', 'text', 'Заголовок статьи');
        $Form->addInput('post_url', '', 'text', 'Url статьи');
        $Form->addInput('is_magnet', '', 'checkbox', 'В прелинковку');
        $Form->addInput('is_publish','', 'checkbox', 'Опубликовано');
        $Form->addInput('is_postponed','', 'checkbox', 'Отложено');
        $Form->addInput('update_ar_date','', 'date', 'Было Обновленно');
        $Form->addInput('ar_avatar', '', 'file');
        $Form->addTextarea('ar_desc', '', 'Краткое описание');
        $Form->addTinymce('tinymce', '', 'Контент Статьи');


        if($this->session->has('Error'))
        {
            $Form->formError($this->session->get('Error'));
        }
        $this->session->remove('Error');
        
        $this->view->data['Form']    = $Form;
        $this->view->data['backUrl'] = $this->url.$urlCategory;

        return $this->view->render('admin/index.html');
        
    }

    function insert($request)
    {
        $error = array();
        if(empty($request['ar_title']))
        {
            $error[] = ['ar_title', 'Ваше поле Заголовок пустое так не должно быть!'];
            $error[] = ['post_url', 'Ваше поле Улр пустое так не должно быть!'];
        }
        
        if(empty($request['post_url']))
        {
            $request['post_url'] = $this->validate->parseUrl($request['ar_title']);
        }else{
            $request['post_url'] = $this->validate->parseUrl($request['post_url']);
        }
        
       if(isset($request['is_postponed']))
       { 
            $request['is_postponed'] = 1;

            if(empty($request['postponed_date']))
            {
                $error[] = ['is_postponed', 'Нужно чтобы поля даты и время не были пустыми!'];
            }

            if(empty($request['postponed_time']))
            {
                $error[] = ['is_postponed', 'Нужно чтобы поля даты и время не были пустыми!'];
            }

            $request['timestamp'] = strtotime($request['postponed_date'].' '.$request['postponed_time']);
        }

        if(empty($request['ar_avatar']['name']))
        {
            $error[] = ['ar_avatar', 'Поле Аватара не может быть пустым!'];
        }else{
            if(!$this->image->checkMimeType($request['ar_avatar']['tmp_name']))
            {
                $error[] = ['ar_avatar', 'Это не картинка'];
            }
        }

        if(empty($request['ar_desc']))
        {
            $error[] = ['ar_desc', 'Добавьте описания статьи, это очень важно!'];
        }

        if(empty($request['tinymce']))
        {
            $error[] = ['tinymce', 'Контент статьи должен содержать хоть что-нибудь!'];
        }

        if(!empty($error))
        {
            $this->session->set('Error', $error);
            return $this->view->redirect('admin/articles/add');
        }
        
        if(isset($request['is_magnet']))
        { 
            $request['is_magnet'] = 1;
        }
        if(isset($request['is_publish']))
        { 
            $request['is_publish'] = 1;
        }
       
        $sourceImagePath = $request['ar_avatar'];
        $request['ar_avatar'] = 'cararac_small_'.date('Y_m_d_h_i',time()).'.webp';
        unset($request['csrf']);
        $request['ar_text'] = $_POST['tinymce'];
        unset($request['tinymce']);
        $request['ar_date'] = time();

        if($this->article->addArticle($request))
        {
            $this->image->resizeAndConvertToWebP($sourceImagePath['tmp_name'], DIR_INDEX.'img/blog/small/'.$request['ar_avatar'], 330);
        
            $this->session->set('Access', "Запись прошла успешно, данные в Базе!");
            return $this->view->redirect('admin/articles');
        }

        $this->session->set('Error', "Что-то пошло не так и запись в Базу данных закончилось с ошибкой! Обратитесь к Программисту 0_o ) !");
        return $this->view->redirect('admin/articles/add');

    }


    function editAction($urlCategory, $id)
    {
        $Article = $this->article->getArticle($id);
       
        if($Article)
        {
            $Form = new Form(); 

            $Form->addSubmit('Сохранить', 'btn');
            $Form->action =  $this->url.$urlCategory.'/edit';
            $Form->addSelect('id_author', [1 => 'Dmitry Sapko', 2 => 'Mohamed Salah'], 'Автор статьи', $Article['id_author']);
            $Form->addInput('ar_id', $Article['ar_id'], 'hidden');
            $Form->addInput('ar_title', $Article['ar_title'], 'text', 'Заголовок статьи');
            $Form->addInput('post_url', $Article['post_url'], 'text', 'Url статьи');
            $Form->addInput('is_magnet', $Article['is_magnet'], 'checkbox', 'В прелинковку');
            $Form->addInput('is_publish', $Article['is_publish'], 'checkbox', 'Опубликовано');
            $Form->addInput('is_postponed', $Article['is_postponed'], 'checkbox', 'Отложено');
            $Form->addInput('update_ar_date', '', 'date', 'Было Обновленно');
            $Form->addInput('ar_avatar', $Article['ar_avatar'], 'file');
            $Form->addTextarea('ar_desc', $Article['ar_desc'], 'Краткое описание');
            $Form->addTinymce('tinymce', $Article['ar_text'], 'Контент Статьи');

            if($this->session->has('Error'))
            {
                $Form->formError($this->session->get('Error'));
            }
            $this->session->remove('Error');
       
            $this->view->data['Form']  = $Form;
            $this->view->data['dataPostponed'] = array($Article['postponed_date'], $Article['postponed_time']);
            $this->view->data['deleteUrl']  = $this->url.$urlCategory."/delete/$id";
            $this->view->data['backUrl']    = $this->url.$urlCategory;

            return $this->view->render('admin/index.html');
        }
        return $this->view->error();
    }


    function update($request)
    {
        $id = $request['ar_id'];

        $error = array();
        if(empty($request['ar_title']))
        {
            $error[] = ['ar_title', 'Ваше поле Заголовок пустое так не должно быть!'];
            $error[] = ['post_url', 'Ваше поле Улр пустое так не должно быть!'];
        }
        
        if(empty($request['post_url']))
        {
            $request['post_url'] = $this->validate->parseUrl($request['ar_title']);
        }else{
            $request['post_url'] = $this->validate->parseUrl($request['post_url']);
        }
        
        if(isset($request['is_magnet']))
        { 
            $request['is_magnet'] = 1;
        }else{
            $request['is_magnet'] = 0;
        }
        
        if(isset($request['is_publish']))
        { 
            $request['is_publish']   = 1;
        }else{
            $request['is_publish']   = 0;
        }

        if(isset($request['is_postponed']))
        { 
            $request['is_postponed'] = 1;

            if(empty($request['postponed_date']))
            {
                $error[] = ['is_postponed', 'Нужно чтобы поля даты и время не были пустыми!'];
            }

            if(empty($request['postponed_time']))
            {
                $error[] = ['is_postponed', 'Нужно чтобы поля даты и время не были пустыми!'];
            }

            $request['timestamp'] = strtotime($request['postponed_date'].' '.$request['postponed_time']);
        }else{
            $request['is_postponed'] = 0;
        }

        if(empty($request['ar_desc']))
        {
            $error[] = ['ar_desc', 'Добавьте описания статьи, это очень важно!'];
        }

        if(empty($request['tinymce']))
        {
            $error[] = ['tinymce', 'Контент статьи должен содержать хоть что-нибудь!'];
        }
       
        if(!empty($request['ar_avatar']['name']))
        {

            if(!$this->image->checkMimeType($request['ar_avatar']['tmp_name']))
            {
                $error[] = ['ar_avatar', 'Это не картинка'];
            }

            $sourceImagePath = $request['ar_avatar'];
            $request['ar_avatar'] = 'cararac_small_'.date('Y_m_d_h_i',time()).'.webp';
            $this->image->resizeAndConvertToWebP($sourceImagePath['tmp_name'], DIR_INDEX.'img/blog/small/'.$request['ar_avatar'], 330);
        }

        if(!empty($error))
        {
            $this->session->set('Error', $error);
            return $this->view->redirect("admin/articles/edit/{$id}");
        }

        unset($request['ar_avatar']);
        unset($request['ar_id']);
        unset($request['csrf']);
        $request['ar_text'] = $_POST['tinymce'];
        unset($request['tinymce']);
       

        if($this->article->editArticle($id, $request))
        {
            $this->session->set('Access', "Обновление прошло замечательно, не переживайте)!");
            return $this->view->redirect('admin/articles');
        }

        $this->session->set('Error', "Что-то пошло не так и запись в Базу данных закончилось с ошибкой! Обратитесь к Программисту 0_o ) !");
        return $this->view->redirect("admin/articles/edit/{$id}");

    }



    function removeAction($urlCategory, $id)
    {
        $Article = $this->article->getArticleForDelete($id);
       
        if($Article)
        {
            $Form = new Form(); 

            if($this->session->has('Error'))
            {
                $this->view->data['ErrorDelete'] = $this->session->get('Error');
            }
            $this->session->remove('Error');

            $this->view->data['deleteData'] = array('keys' => array_keys($Article), 'values' => array_values($Article));
            $this->view->data['deleteUrl']  = $this->url.$urlCategory."/delete";
            $this->view->data['editUrl']    = $this->url.$urlCategory."/edit/$id";
            $this->view->data['backUrl']    = $this->url.$urlCategory;

            return $this->view->render('admin/index.html');
        }
        return $this->view->error();
    }

    function delete($request)
    {
        $id = $request['ar_id'];
        if($this->article->delArticle($id))
        {
            $this->session->set('Access', "Вы удалили, данные из Базе ) !!");
            return $this->view->redirect('admin/articles');
        }
        $this->session->set('Error', "Что-то пошло не так и запись в Базу данных закончилось с ошибкой! Обратитесь к Программисту 0_o ) !");
        return $this->view->redirect("admin/articles/delete/{$id}");
    }

}
