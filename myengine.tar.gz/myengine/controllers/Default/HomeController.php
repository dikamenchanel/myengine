<?php

namespace controllers\Default;

use controllers\Controller;
use models\default\HomeModel;


class HomeController extends Controller
{
    private $home;


    function __construct()
    {
        parent::__construct();
        $this->home = new HomeModel();
    }


    function index()
    {
        $this->view->data['mainPage']  = $this->home->getMainTags();
        $this->view->data['menu']      = $this->home->getDataTags();
        
        return $this->view->render('default/index.html');
    }

    function about()
    {
        echo "About Page US";
    }
    
    function category($url)
    {
        $category = $this->home->getCategory($url);
    
        if($category)
        {

            $this->view->data['title'] = "Its Cararac.com Category {$url}";
            $this->view->data['car'] = $category->title;

            return $this->view->render('default/category.html');
        }

        return $this->view->error();
    }
}
