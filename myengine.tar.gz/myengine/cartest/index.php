<?php 


require_once "../lib/debug.php";

require_once "../lib/site.ini.php";

require_once "../lib/Autoloader.php";

require_once "../lib/web.php";

