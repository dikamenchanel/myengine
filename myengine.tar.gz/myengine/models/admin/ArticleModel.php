<?php

namespace models\admin;

use models\Model;

class ArticleModel extends Model
{


    function __construct()
    {
        parent::__construct();
    }

    /**
     * method@ArticleModel::getDataArticles($page, $sort) 
     *
     * return array
     * */ 
    function getDataArticles($page, $sort)
    {
        $page = (int)$page * PGN_ADMIN;

        $result = $this->db->select("select 
                                    ar_id, 
                                    from_unixtime(ar_date, '%d-%m-%Y') as date, 
                                    ar_title, 
                                    is_publish from article
                                    order by ar_id $sort limit :limit, 25", [':limit' => $page]);
        
        return $result;
    }

    /**
     * method@ArticleModel::getCountInfoArticles()
     *  
     * return integer
     * */
    function getCountInfoArticles()
    {
        $result = $this->db->selectOne("select count(*) as count
                                    from article
                                    where 1", []);
        return $result['count'];
    }

    /**
     * method@ArticleModel::getArticle($id)
     * 
     * return @array or false
     * */
    function getArticle($id)
    {
        $result = $this->db->selectOne("select * from article where ar_id = :id", [':id' => $id]);
        return (intval($result) > 0) ? $result : false;
    }

    /**
     * method@ArticleModel::addArticle($requset)
     * 
     * return true or false
     * */
    function addArticle($requset)
    {

        $result = $this->db->insert('article', $requset);   
        return (intval($result) > 0) ? true : false;
    }

    /**
     * method@ArticleModel::editArticle($id,$requset)
     * 
     * return true or false
     * */
    function editArticle($id, $requset)
    {
        $result = $this->db->update('article', $requset, "ar_id = $id");
        return (intval($result) > 0) ? true : false;
    }



    /**
     * method@ArticleModel::getArticle($id)
     * 
     * return @array or false
     * */
    function getArticleForDelete($id)
    {
        $result = $this->db->selectOne("select ar_id, ar_title from article where ar_id = :id", [':id' => $id]);
        return (intval($result) > 0) ? $result : false;
    }

    /**
     * method@ArticleModel::addUser()
     * 
     * return true or false
     * */
    function delArticle($id)
    {
        $result = $this->db->delete('article', "ar_id = $id");
        return (intval($result) > 0) ? true : false;
    }
}
