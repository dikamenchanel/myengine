<?php

namespace models\default;

use models\Model;

class HomeModel extends Model
{
    function __construct()
    {
        parent::__construct();
    }

    function getDataTags()
    {
        $result = $this->db->getCache('A_tags');
        
        if($result !== Null)
        {
            $urls = array();
            $arrayMenu = array();
            $blokMenuMainPage = array();
            $urlComparison = '';

            foreach($result as $key => $value)
            {

                // Собираем Урлы  для Больших зеленых кнопок на главной страницы, переход на популярные категории
                if($value->id == 12 || $value->id == 18 || $value->id  ==  10 || $value->id  == 9 || $value->id == 13)
                {
                    $blokMenuMainPage[$value->id] = $value;
                }

                // Собираем Урлы  для перелинковке на главной внизу страницы
                if($value->id == 40 )
                    $urls[0] = $value->url;
                if($value->id == 41 )
                    $urls[1] = $value->url;
                if($value->id  ==  15)
                    $urls[2] = $value->url;

                // Урл сравнения для главной страницы
                if($value->id  == 3)
                {
                    $urlComparison = $value->url;
                }


                if($value->category_id == 2)
                {
                    $arrayMenu['spare_parts'][$value->groupname][] = $value;
                }
                if($value->category_id == 3)
                {
                    $arrayMenu['dimensions'][] = $value;
                }

                if($value->category_id == 4)
                {
                    $arrayMenu['characteristics'][] = $value;
                }
                if($value->category_id == 0)
                {
                    $arrayMenu[$value->name] = $value;
                }
            }
            return [$arrayMenu, $blokMenuMainPage, $urls, $urlComparison];
        } else {
            
            $result = $this->db->select('select id, name, url, category_id, groupname from A_tags where category_type != :category_type', ['category_type' => -1]);
            
            $urls = array();
            $arrayMenu = array();
            $blokMenuMainPage = array();
            $urlComparison = '';

            foreach($result as $key => $value)
            {

                // Собираем Урлы  для Больших зеленых кнопок на главной страницы, переход на популярные категории
                if($value['id'] == 12 || $value['id'] == 18 ||$value['id']  ==  10 || $value['id']  == 9 || $value['id'] == 13)
                {
                    $blokMenuMainPage[$value['id']] = $value;
                }

                // Собираем Урлы  для перелинковке на главной внизу страницы
                if($value['id'] == 40 )
                    $urls[0] = $value['url'];
                if($value['id'] == 41 )
                    $urls[1] = $value['url'];
                if($value['id']  ==  15)
                    $urls[2] = $value['url'];

                // Урл сравнения для главной страницы
                if($value['id']  == 3)
                {
                    $urlComparison = $value['url'];
                }

                if($value['category_id'] == 2)
                {
                    $arrayMenu['spare_parts'][$value['groupname']][] = $value;
                }
                if($value['category_id'] == 3)
                {
                    $arrayMenu['dimensions'][] = $value;
                }

                if($value['category_id'] == 4)
                {
                    $arrayMenu['characteristics'][] = $value;
                }
                if($value['category_id'] == 0)
                {
                    $arrayMenu[$value['name']] = $value;
                }
            }

            // d($arrayMenu);

            $this->db->setCache('A_tags', $result);
            
            return [$arrayMenu, $blokMenuMainPage, $urls, $urlComparison];
        }
    }

    function getMainTags()
    {
        $result = $this->db->getCache('A_tags_main');

        if($result !== Null)
        {
            return $result;
        } else {
            
            $result = $this->db->selectOne('select * from A_tags where category_id = :category_id', ['category_id' => -1]);
            
            $this->db->setCache('A_tags_main', $result);
            
            return $result;
        }
    }



    function getCategory($url)
    {
        $result = $this->db->getCache('A_tags_'.$url);

        if($result !== Null)
        {
            if($result->url === $url)
            {
                return $result;
            }
            return false;
        } else {
            
            $result = $this->db->selectOne('select * from A_tags where url = :url', ['url' => $url]);
            
            $this->db->setCache('A_tags_'.$url, $result);
            
            return $result;
        }
    }
}
