 <?php

use lib\Twig\Environment;
use lib\Twig\Error\LoaderError;
use lib\Twig\Error\RuntimeError;
use lib\Twig\Extension\SandboxExtension;
use lib\Twig\Markup;
use lib\Twig\Sandbox\SecurityError;
use lib\Twig\Sandbox\SecurityNotAllowedTagError;
use lib\Twig\Sandbox\SecurityNotAllowedFilterError;
use lib\Twig\Sandbox\SecurityNotAllowedFunctionError;
use lib\Twig\Source;
use lib\Twig\Template;

/* base.html */
class __TwigTemplate_4c6b6716d9c6cb7da04d8a877f4b2a74 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'header' => [$this, 'block_header'],
            'content' => [$this, 'block_content'],
            'footer' => [$this, 'block_footer'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"UTF-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    ";
        // line 6
        $this->displayBlock('title', $context, $blocks);
        // line 15
        echo "
    <link rel=\"icon\" href=\"/img/favicon.ico\">
    <link defer rel=\"stylesheet\" href=\"/css/style.css\">
</head>
<body>
    <header>
    ";
        // line 21
        $this->displayBlock('header', $context, $blocks);
        // line 24
        echo "    </header>
    <main>
        ";
        // line 26
        $this->displayBlock('content', $context, $blocks);
        // line 27
        echo "    </main>
    <footer>
    ";
        // line 29
        $this->displayBlock('footer', $context, $blocks);
        // line 30
        echo "    </footer>
</body>
</html> 
";
    }

    // line 6
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 7
        echo "        ";
        if (($context["mainPage"] ?? null)) {
            // line 8
            echo "            <meta name=\"description\" content=\"";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["mainPage"] ?? null), "description", [], "any", false, false, false, 8), "html", null, true);
            echo "\">
            <title>";
            // line 9
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["mainPage"] ?? null), "title", [], "any", false, false, false, 9), "html", null, true);
            echo "</title>
        ";
        } else {
            // line 11
            echo "            <meta name=\"descriptioin\" content=\"";
            echo twig_escape_filter($this->env, ($context["description"] ?? null), "html", null, true);
            echo "\">
            <title>";
            // line 12
            echo twig_escape_filter($this->env, ($context["title"] ?? null), "html", null, true);
            echo "</title>
        ";
        }
        // line 14
        echo "    ";
    }

    // line 21
    public function block_header($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 22
        echo "        ";
        $this->loadTemplate("common/nav.html", "base.html", 22)->display($context);
        // line 23
        echo "    ";
    }

    // line 26
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
    }

    // line 29
    public function block_footer($context, array $blocks = [])
    {
        $macros = $this->macros;
    }

    public function getTemplateName()
    {
        return "base.html";
    }

    public function getDebugInfo()
    {
        return array (  127 => 29,  121 => 26,  117 => 23,  114 => 22,  110 => 21,  106 => 14,  101 => 12,  96 => 11,  91 => 9,  86 => 8,  83 => 7,  79 => 6,  72 => 30,  70 => 29,  66 => 27,  64 => 26,  60 => 24,  58 => 21,  50 => 15,  48 => 6,  41 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "base.html", "/var/www/cartest/data/www/cartest.new/templates/base.html");
    }
}
