 <?php

use lib\Twig\Environment;
use lib\Twig\Error\LoaderError;
use lib\Twig\Error\RuntimeError;
use lib\Twig\Extension\SandboxExtension;
use lib\Twig\Markup;
use lib\Twig\Sandbox\SecurityError;
use lib\Twig\Sandbox\SecurityNotAllowedTagError;
use lib\Twig\Sandbox\SecurityNotAllowedFilterError;
use lib\Twig\Sandbox\SecurityNotAllowedFunctionError;
use lib\Twig\Source;
use lib\Twig\Template;

/* common/nav.html */
class __TwigTemplate_d85d0ab81d5ecf4a7d04e2e2a20e3906 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<nav>
    <ul>
        <li><a href=\"/\"><img src=\"\" alt=\"Cararac.com\" width=\"205\" height=\"87\"></a></li>
        ";
        // line 4
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, ($context["menu"] ?? null), 0, [], "any", false, false, false, 4));
        foreach ($context['_seq'] as $context["key"] => $context["item"]) {
            // line 5
            echo "                ";
            if (($context["key"] == "characteristics")) {
                // line 6
                echo "                    <li>
                        <span>Characteristics</span>
                        <ol class=\"characteristics\">
                        ";
                // line 9
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable($context["item"]);
                foreach ($context['_seq'] as $context["_key"] => $context["subItem"]) {
                    // line 10
                    echo "                        <li><a href=\"/";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["subItem"], "url", [], "any", false, false, false, 10), "html", null, true);
                    echo "\">";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["subItem"], "name", [], "any", false, false, false, 10), "html", null, true);
                    echo "</a></li>
                        ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['subItem'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 12
                echo "                        </ol>
                    </li>
                ";
            } elseif ((            // line 14
$context["key"] == "dimensions")) {
                // line 15
                echo "                    <li>
                        <span>Dimensions</span>
                        <ol class=\"dimensions\">
                        ";
                // line 18
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable($context["item"]);
                foreach ($context['_seq'] as $context["_key"] => $context["subItem"]) {
                    // line 19
                    echo "                        <li><a href=\"/";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["subItem"], "url", [], "any", false, false, false, 19), "html", null, true);
                    echo "\">";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["subItem"], "name", [], "any", false, false, false, 19), "html", null, true);
                    echo "</a></li>
                        ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['subItem'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 21
                echo "                        </ol>
                    </li>
                ";
            } elseif ((            // line 23
$context["key"] == "spare_parts")) {
                // line 24
                echo "                    <li>
                        <span>Spare Parts</span>
                        <ol class=\"spare_parts\">
                        ";
                // line 27
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable($context["item"]);
                foreach ($context['_seq'] as $context["_key"] => $context["subItem"]) {
                    // line 28
                    echo "                        <li>
                            <span><b>";
                    // line 29
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["subItem"], 0, [], "any", false, false, false, 29), "groupname", [], "any", false, false, false, 29), "html", null, true);
                    echo "</b></span>
                            ";
                    // line 30
                    $context['_parent'] = $context;
                    $context['_seq'] = twig_ensure_traversable($context["subItem"]);
                    foreach ($context['_seq'] as $context["_key"] => $context["value"]) {
                        // line 31
                        echo "                                <a href=\"/";
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["value"], "url", [], "any", false, false, false, 31), "html", null, true);
                        echo "\">";
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["value"], "name", [], "any", false, false, false, 31), "html", null, true);
                        echo "</a>
                            ";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['_key'], $context['value'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                    // line 32
                    echo "    
                        </li>
                        ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['subItem'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 35
                echo "                        </ol>
                    </li>
                ";
            } else {
                // line 38
                echo "                    <li><a href=\"/";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["item"], "url", [], "any", false, false, false, 38), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $context["key"], "html", null, true);
                echo "</a></li>
                ";
            }
            // line 40
            echo "        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 41
        echo "        <li><a href=\"/blog\">Blog</a></li>
    </ul>
</nav> 
";
    }

    public function getTemplateName()
    {
        return "common/nav.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  159 => 41,  153 => 40,  145 => 38,  140 => 35,  132 => 32,  121 => 31,  117 => 30,  113 => 29,  110 => 28,  106 => 27,  101 => 24,  99 => 23,  95 => 21,  84 => 19,  80 => 18,  75 => 15,  73 => 14,  69 => 12,  58 => 10,  54 => 9,  49 => 6,  46 => 5,  42 => 4,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "common/nav.html", "/var/www/cartest/data/www/cartest.new/templates/common/nav.html");
    }
}
