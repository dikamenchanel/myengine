 <?php

use lib\Twig\Environment;
use lib\Twig\Error\LoaderError;
use lib\Twig\Error\RuntimeError;
use lib\Twig\Extension\SandboxExtension;
use lib\Twig\Markup;
use lib\Twig\Sandbox\SecurityError;
use lib\Twig\Sandbox\SecurityNotAllowedTagError;
use lib\Twig\Sandbox\SecurityNotAllowedFilterError;
use lib\Twig\Sandbox\SecurityNotAllowedFunctionError;
use lib\Twig\Source;
use lib\Twig\Template;

/* admin/Form.html */
class __TwigTemplate_255c4b7d5895e8ffc9d1f00146618de4 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        if (twig_get_attribute($this->env, $this->source, ($context["Form"] ?? null), "error", [], "any", false, false, false, 1)) {
            // line 2
            echo "<div class=\"error-status\">
    <p> * ";
            // line 3
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["Form"] ?? null), "error", [], "any", false, false, false, 3), "html", null, true);
            echo "</p>
</div>
";
        }
        // line 6
        echo "
<form id=\"form_action\" action=\"";
        // line 7
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["Form"] ?? null), "action", [], "any", false, false, false, 7), "html", null, true);
        echo "\" method=\"post\" enctype=\"multipart/form-data\"> 

<input type=\"hidden\" name=\"csrf\" value=\"";
        // line 9
        echo twig_escape_filter($this->env, ($context["_token"] ?? null), "html", null, true);
        echo "\">

";
        // line 11
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, ($context["Form"] ?? null), "form", [], "any", false, false, false, 11));
        foreach ($context['_seq'] as $context["_key"] => $context["obj"]) {
            // line 12
            echo "    
    ";
            // line 14
            echo "    ";
            if ((twig_get_attribute($this->env, $this->source, $context["obj"], "tag", [], "any", false, false, false, 14) == "button")) {
                // line 15
                echo "        <button type=\"submit\" class=\"";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["obj"], "class", [], "any", false, false, false, 15), "html", null, true);
                echo "\" id=\"";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["obj"], "id", [], "any", false, false, false, 15), "html", null, true);
                echo "\"><i class=\"fa-solid fa-download fa-2xl\"></i>&nbsp;&nbsp;";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["obj"], "value", [], "any", false, false, false, 15), "html", null, true);
                echo "</button>
        ";
                // line 16
                if (($context["deleteUrl"] ?? null)) {
                    // line 17
                    echo "        <a href=\"";
                    echo twig_escape_filter($this->env, ($context["deleteUrl"] ?? null), "html", null, true);
                    echo "\"><i class=\"fa-solid fa-xmark fa-2xl\"></i>&nbsp;&nbsp;Удалить</a>
        ";
                }
                // line 19
                echo "    ";
            }
            // line 20
            echo "


    ";
            // line 24
            echo "    ";
            if ((twig_get_attribute($this->env, $this->source, $context["obj"], "tag", [], "any", false, false, false, 24) == "select")) {
                // line 25
                echo "            <div class=\"wrapper\">
                <label for=\"";
                // line 26
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["obj"], "id", [], "any", false, false, false, 26), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["obj"], "label", [], "any", false, false, false, 26), "html", null, true);
                echo "</label>
                <select name=\"";
                // line 27
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["obj"], "name", [], "any", false, false, false, 27), "html", null, true);
                echo "\" id=\"";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["obj"], "id", [], "any", false, false, false, 27), "html", null, true);
                echo "\" class=\"";
                if (twig_get_attribute($this->env, $this->source, $context["obj"], "error", [], "any", false, false, false, 27)) {
                    echo "error_wrapper";
                }
                echo "\">
                    ";
                // line 28
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, $context["obj"], "option", [], "any", false, false, false, 28));
                foreach ($context['_seq'] as $context["key"] => $context["item"]) {
                    // line 29
                    echo "                        ";
                    if ((twig_get_attribute($this->env, $this->source, $context["obj"], "selected", [], "any", false, false, false, 29) == $context["key"])) {
                        // line 30
                        echo "                        <option selected value=\"";
                        echo twig_escape_filter($this->env, $context["key"], "html", null, true);
                        echo "\">";
                        echo twig_escape_filter($this->env, $context["item"], "html", null, true);
                        echo "</option>
                        ";
                    } else {
                        // line 32
                        echo "                        <option value=\"";
                        echo twig_escape_filter($this->env, $context["key"], "html", null, true);
                        echo "\">";
                        echo twig_escape_filter($this->env, $context["item"], "html", null, true);
                        echo "</option>
                        ";
                    }
                    // line 34
                    echo "                    ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['key'], $context['item'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 35
                echo "                </select>
                ";
                // line 36
                if (twig_get_attribute($this->env, $this->source, $context["obj"], "error", [], "any", false, false, false, 36)) {
                    // line 37
                    echo "                    <span class=\"error\">*&nbsp;";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["obj"], "errorMsg", [], "any", false, false, false, 37), "html", null, true);
                    echo "</span>
                ";
                }
                // line 39
                echo "            </div>
    ";
            }
            // line 41
            echo "


    ";
            // line 45
            echo "    ";
            if ((twig_get_attribute($this->env, $this->source, $context["obj"], "tag", [], "any", false, false, false, 45) == "input")) {
                // line 46
                echo "            <div class=\"wrapper\">
                <label for=\"";
                // line 47
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["obj"], "id", [], "any", false, false, false, 47), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["obj"], "label", [], "any", false, false, false, 47), "html", null, true);
                echo "</label>
                <input type=\"";
                // line 48
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["obj"], "type", [], "any", false, false, false, 48), "html", null, true);
                echo "\" name=\"";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["obj"], "name", [], "any", false, false, false, 48), "html", null, true);
                echo "\" id=\"";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["obj"], "id", [], "any", false, false, false, 48), "html", null, true);
                echo "\" class=\"";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["obj"], "class", [], "any", false, false, false, 48), "html", null, true);
                echo " ";
                if (twig_get_attribute($this->env, $this->source, $context["obj"], "error", [], "any", false, false, false, 48)) {
                    echo "error_wrapper";
                }
                echo "\" value=\"";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["obj"], "value", [], "any", false, false, false, 48), "html", null, true);
                echo "\"  ";
                if (((twig_get_attribute($this->env, $this->source, $context["obj"], "type", [], "any", false, false, false, 48) == "checkbox") && twig_get_attribute($this->env, $this->source, $context["obj"], "value", [], "any", false, false, false, 48))) {
                    echo "checked";
                }
                echo ">
                ";
                // line 49
                if (twig_get_attribute($this->env, $this->source, $context["obj"], "error", [], "any", false, false, false, 49)) {
                    // line 50
                    echo "                    <span class=\"error\">*&nbsp;";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["obj"], "errorMsg", [], "any", false, false, false, 50), "html", null, true);
                    echo "</span>
                ";
                }
                // line 52
                echo "                ";
                if (((twig_get_attribute($this->env, $this->source, $context["obj"], "name", [], "any", false, false, false, 52) == "is_postponed") && twig_get_attribute($this->env, $this->source, $context["obj"], "value", [], "any", false, false, false, 52))) {
                    // line 53
                    echo "                <script>
                    var dataPostponed = ";
                    // line 54
                    echo json_encode(($context["dataPostponed"] ?? null));
                    echo ";
                </script>                
                ";
                }
                // line 57
                echo "                ";
                if ((twig_get_attribute($this->env, $this->source, $context["obj"], "type", [], "any", false, false, false, 57) == "file")) {
                    // line 58
                    echo "                    <span class=\"output\"><img id=\"image-preview\" src=\"";
                    if (twig_get_attribute($this->env, $this->source, $context["obj"], "value", [], "any", false, false, false, 58)) {
                        echo "http://185.4.73.209:7777/cartest.new/img/blog/small/";
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["obj"], "value", [], "any", false, false, false, 58), "html", null, true);
                    } else {
                        echo "#";
                    }
                    echo "\" alt=\"Image Preview\" width=\"220\"></span>
                ";
                }
                // line 60
                echo "            </div>
    ";
            }
            // line 62
            echo "

    ";
            // line 65
            echo "    ";
            if ((twig_get_attribute($this->env, $this->source, $context["obj"], "tag", [], "any", false, false, false, 65) == "textarea")) {
                // line 66
                echo "            <div class=\"wrapper\">
                <label for=\"";
                // line 67
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["obj"], "id", [], "any", false, false, false, 67), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["obj"], "label", [], "any", false, false, false, 67), "html", null, true);
                echo "</label>
                <textarea name=\"";
                // line 68
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["obj"], "name", [], "any", false, false, false, 68), "html", null, true);
                echo "\" id=\"";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["obj"], "id", [], "any", false, false, false, 68), "html", null, true);
                echo "\" cols=\"";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["obj"], "cols", [], "any", false, false, false, 68), "html", null, true);
                echo "\" rows=\"";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["obj"], "rows", [], "any", false, false, false, 68), "html", null, true);
                echo "\" class=\"";
                if (twig_get_attribute($this->env, $this->source, $context["obj"], "error", [], "any", false, false, false, 68)) {
                    echo "error_wrapper";
                }
                echo "\">";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["obj"], "value", [], "any", false, false, false, 68), "html", null, true);
                echo "</textarea>
                ";
                // line 69
                if (twig_get_attribute($this->env, $this->source, $context["obj"], "error", [], "any", false, false, false, 69)) {
                    // line 70
                    echo "                    <span class=\"error\">*&nbsp;";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["obj"], "errorMsg", [], "any", false, false, false, 70), "html", null, true);
                    echo "</span>
                ";
                }
                // line 72
                echo "            </div>
    ";
            }
            // line 74
            echo "

    ";
            // line 77
            echo "    ";
            if ((twig_get_attribute($this->env, $this->source, $context["obj"], "tag", [], "any", false, false, false, 77) == "tinymce")) {
                // line 78
                echo "            <div class=\"wrapper textarea\">
                <label for=\"";
                // line 79
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["obj"], "id", [], "any", false, false, false, 79), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["obj"], "label", [], "any", false, false, false, 79), "html", null, true);
                echo "</label>
                <textarea name=\"";
                // line 80
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["obj"], "name", [], "any", false, false, false, 80), "html", null, true);
                echo "\" id=\"";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["obj"], "id", [], "any", false, false, false, 80), "html", null, true);
                echo "\" class=\"";
                if (twig_get_attribute($this->env, $this->source, $context["obj"], "error", [], "any", false, false, false, 80)) {
                    echo "error_wrapper";
                }
                echo "\">";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["obj"], "value", [], "any", false, false, false, 80), "html", null, true);
                echo "</textarea>
                ";
                // line 81
                if (twig_get_attribute($this->env, $this->source, $context["obj"], "error", [], "any", false, false, false, 81)) {
                    // line 82
                    echo "                    <span class=\"error\">*&nbsp;";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["obj"], "errorMsg", [], "any", false, false, false, 82), "html", null, true);
                    echo "</span>
                ";
                }
                // line 84
                echo "            </div>
    ";
            }
            // line 86
            echo "
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['obj'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 88
        echo "
</form> 
";
    }

    public function getTemplateName()
    {
        return "admin/Form.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  328 => 88,  321 => 86,  317 => 84,  311 => 82,  309 => 81,  297 => 80,  291 => 79,  288 => 78,  285 => 77,  281 => 74,  277 => 72,  271 => 70,  269 => 69,  253 => 68,  247 => 67,  244 => 66,  241 => 65,  237 => 62,  233 => 60,  222 => 58,  219 => 57,  213 => 54,  210 => 53,  207 => 52,  201 => 50,  199 => 49,  179 => 48,  173 => 47,  170 => 46,  167 => 45,  162 => 41,  158 => 39,  152 => 37,  150 => 36,  147 => 35,  141 => 34,  133 => 32,  125 => 30,  122 => 29,  118 => 28,  108 => 27,  102 => 26,  99 => 25,  96 => 24,  91 => 20,  88 => 19,  82 => 17,  80 => 16,  71 => 15,  68 => 14,  65 => 12,  61 => 11,  56 => 9,  51 => 7,  48 => 6,  42 => 3,  39 => 2,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "admin/Form.html", "/var/www/cartest/data/www/cartest.new/templates/admin/Form.html");
    }
}
