 <?php

use lib\Twig\Environment;
use lib\Twig\Error\LoaderError;
use lib\Twig\Error\RuntimeError;
use lib\Twig\Extension\SandboxExtension;
use lib\Twig\Markup;
use lib\Twig\Sandbox\SecurityError;
use lib\Twig\Sandbox\SecurityNotAllowedTagError;
use lib\Twig\Sandbox\SecurityNotAllowedFilterError;
use lib\Twig\Sandbox\SecurityNotAllowedFunctionError;
use lib\Twig\Source;
use lib\Twig\Template;

/* admin/Table.html */
class __TwigTemplate_47389cdb143a3fc989e2fcf76062db0f extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        if (($context["Access"] ?? null)) {
            // line 2
            echo "<div class=\"access\">
    <p>";
            // line 3
            echo twig_escape_filter($this->env, ($context["Access"] ?? null), "html", null, true);
            echo "</p>
</div>
";
        }
        // line 6
        echo "

<div class=\"table\">
    <ul class=\"table-title\">
    ";
        // line 10
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, ($context["Table"] ?? null), "titles", [], "any", false, false, false, 10));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["title"]) {
            // line 11
            echo "        ";
            if (($context["title"] == "actions")) {
                // line 12
                echo "            <li style=\"width:200px;justify-content:space-around;";
                echo twig_escape_filter($this->env, (($__internal_compile_0 = twig_get_attribute($this->env, $this->source, ($context["Table"] ?? null), "style", [], "any", false, false, false, 12)) && is_array($__internal_compile_0) || $__internal_compile_0 instanceof ArrayAccess ? ($__internal_compile_0[twig_get_attribute($this->env, $this->source, $context["loop"], "index0", [], "any", false, false, false, 12)] ?? null) : null), "html", null, true);
                echo "\">
                ";
                // line 13
                echo twig_escape_filter($this->env, $context["title"], "html", null, true);
                echo "
            </li>
        ";
            } elseif ((            // line 15
$context["title"] == "link")) {
                // line 16
                echo "            <li style=\"width:100px;justify-content:space-around;";
                echo twig_escape_filter($this->env, (($__internal_compile_1 = twig_get_attribute($this->env, $this->source, ($context["Table"] ?? null), "style", [], "any", false, false, false, 16)) && is_array($__internal_compile_1) || $__internal_compile_1 instanceof ArrayAccess ? ($__internal_compile_1[twig_get_attribute($this->env, $this->source, $context["loop"], "index0", [], "any", false, false, false, 16)] ?? null) : null), "html", null, true);
                echo "\">
                ";
                // line 17
                echo twig_escape_filter($this->env, $context["title"], "html", null, true);
                echo "
            </li>
        ";
            } else {
                // line 20
                echo "            <li style=\"";
                echo twig_escape_filter($this->env, (($__internal_compile_2 = twig_get_attribute($this->env, $this->source, ($context["Table"] ?? null), "style", [], "any", false, false, false, 20)) && is_array($__internal_compile_2) || $__internal_compile_2 instanceof ArrayAccess ? ($__internal_compile_2[twig_get_attribute($this->env, $this->source, $context["loop"], "index0", [], "any", false, false, false, 20)] ?? null) : null), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $context["title"], "html", null, true);
                echo "</li>
        ";
            }
            // line 22
            echo "    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['title'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 23
        echo "    </ul>
    <ul class=\"table-body\">
        ";
        // line 25
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, ($context["Table"] ?? null), "data", [], "any", false, false, false, 25));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["items"]) {
            // line 26
            echo "            ";
            if (((twig_get_attribute($this->env, $this->source, $context["loop"], "index", [], "any", false, false, false, 26) % 2) == 0)) {
                // line 27
                echo "                <li class=\"body-row bg\">
            ";
            } else {
                // line 29
                echo "                <li class=\"body-row\">
            ";
            }
            // line 31
            echo "                <ol>
                ";
            // line 32
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($context["items"]);
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["key"] => $context["item"]) {
                // line 33
                echo "                    ";
                if (($context["key"] == "urlAction")) {
                    // line 34
                    echo "                        <li class=\"row-item\" style=\"width:200px;justify-content:space-around;";
                    echo twig_escape_filter($this->env, (($__internal_compile_3 = twig_get_attribute($this->env, $this->source, ($context["Table"] ?? null), "style", [], "any", false, false, false, 34)) && is_array($__internal_compile_3) || $__internal_compile_3 instanceof ArrayAccess ? ($__internal_compile_3[twig_get_attribute($this->env, $this->source, $context["loop"], "index0", [], "any", false, false, false, 34)] ?? null) : null), "html", null, true);
                    echo "\">
                            <a href=\"";
                    // line 35
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["item"], 0, [], "any", false, false, false, 35), "html", null, true);
                    echo "\"><i class=\"fa-solid fa-pencil fa-xl\"></i></a>
                            <a href=\"";
                    // line 36
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["item"], 1, [], "any", false, false, false, 36), "html", null, true);
                    echo "\"><i class=\"fa-solid fa-xmark fa-xl\"></i></a>
                            ";
                    // line 37
                    if (twig_get_attribute($this->env, $this->source, $context["item"], "input", [], "any", false, false, false, 37)) {
                        // line 38
                        echo "                                <input ";
                        if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["item"], "input", [], "any", false, false, false, 38), "checked", [], "any", false, false, false, 38)) {
                            echo "checked";
                        }
                        echo " type=\"checkbox\" name=\"";
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["item"], "input", [], "any", false, false, false, 38), "name", [], "any", false, false, false, 38), "html", null, true);
                        echo "\" class=\"";
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["item"], "input", [], "any", false, false, false, 38), "name", [], "any", false, false, false, 38), "html", null, true);
                        echo "\" id=\"";
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["item"], "input", [], "any", false, false, false, 38), "name", [], "any", false, false, false, 38), "html", null, true);
                        echo "_";
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["loop"], "index0", [], "any", false, false, false, 38), "html", null, true);
                        echo "\">
                            ";
                    }
                    // line 40
                    echo "                        </li>
                    ";
                } elseif ((                // line 41
$context["key"] == "urlLink")) {
                    // line 42
                    echo "                        <li class=\"row-item\" style=\"width:100px;justify-content:space-around;";
                    echo twig_escape_filter($this->env, (($__internal_compile_4 = twig_get_attribute($this->env, $this->source, ($context["Table"] ?? null), "style", [], "any", false, false, false, 42)) && is_array($__internal_compile_4) || $__internal_compile_4 instanceof ArrayAccess ? ($__internal_compile_4[twig_get_attribute($this->env, $this->source, $context["loop"], "index0", [], "any", false, false, false, 42)] ?? null) : null), "html", null, true);
                    echo "\">
                            <a href=\"";
                    // line 43
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["item"], "href", [], "any", false, false, false, 43), "html", null, true);
                    echo "\" target=\"_blank\"><i class=\"fa-solid fa-square-up-right fa-xl\"></i>";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["item"], "innerHTML", [], "any", false, false, false, 43), "html", null, true);
                    echo "</a>
                        </li>
                    ";
                } else {
                    // line 46
                    echo "                        <li class=\"row-item\" style=\"";
                    echo twig_escape_filter($this->env, (($__internal_compile_5 = twig_get_attribute($this->env, $this->source, ($context["Table"] ?? null), "style", [], "any", false, false, false, 46)) && is_array($__internal_compile_5) || $__internal_compile_5 instanceof ArrayAccess ? ($__internal_compile_5[twig_get_attribute($this->env, $this->source, $context["loop"], "index0", [], "any", false, false, false, 46)] ?? null) : null), "html", null, true);
                    echo "\">";
                    echo twig_escape_filter($this->env, $context["item"], "html", null, true);
                    echo "</li>
                    ";
                }
                // line 48
                echo "                ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['key'], $context['item'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 49
            echo "                </ol>
            </li>
        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['items'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 52
        echo "    </ul>
</div>
";
    }

    public function getTemplateName()
    {
        return "admin/Table.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  261 => 52,  245 => 49,  231 => 48,  223 => 46,  215 => 43,  210 => 42,  208 => 41,  205 => 40,  189 => 38,  187 => 37,  183 => 36,  179 => 35,  174 => 34,  171 => 33,  154 => 32,  151 => 31,  147 => 29,  143 => 27,  140 => 26,  123 => 25,  119 => 23,  105 => 22,  97 => 20,  91 => 17,  86 => 16,  84 => 15,  79 => 13,  74 => 12,  71 => 11,  54 => 10,  48 => 6,  42 => 3,  39 => 2,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "admin/Table.html", "/var/www/cartest/data/www/cartest.new/templates/admin/Table.html");
    }
}
