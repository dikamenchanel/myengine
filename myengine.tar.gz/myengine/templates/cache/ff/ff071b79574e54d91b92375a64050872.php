 <?php

use lib\Twig\Environment;
use lib\Twig\Error\LoaderError;
use lib\Twig\Error\RuntimeError;
use lib\Twig\Extension\SandboxExtension;
use lib\Twig\Markup;
use lib\Twig\Sandbox\SecurityError;
use lib\Twig\Sandbox\SecurityNotAllowedTagError;
use lib\Twig\Sandbox\SecurityNotAllowedFilterError;
use lib\Twig\Sandbox\SecurityNotAllowedFunctionError;
use lib\Twig\Source;
use lib\Twig\Template;

/* common/pagination.html */
class __TwigTemplate_d46cc628168263aa54b8d407ecdbed8c extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<div class=\"pagination\">
    ";
        // line 2
        if (((($__internal_compile_0 = ($context["Pagination"] ?? null)) && is_array($__internal_compile_0) || $__internal_compile_0 instanceof ArrayAccess ? ($__internal_compile_0["active"] ?? null) : null) > 1)) {
            // line 3
            echo "        <li><a class=\"\" href=\"";
            echo twig_escape_filter($this->env, (($__internal_compile_1 = ($context["Pagination"] ?? null)) && is_array($__internal_compile_1) || $__internal_compile_1 instanceof ArrayAccess ? ($__internal_compile_1["url"] ?? null) : null), "html", null, true);
            echo "/page-1\">1</a></li>
    ";
        }
        // line 5
        echo "    ";
        if (((($__internal_compile_2 = ($context["Pagination"] ?? null)) && is_array($__internal_compile_2) || $__internal_compile_2 instanceof ArrayAccess ? ($__internal_compile_2["active"] ?? null) : null) > 1)) {
            // line 6
            echo "        <li><a class=\"\" href=\"";
            echo twig_escape_filter($this->env, (($__internal_compile_3 = ($context["Pagination"] ?? null)) && is_array($__internal_compile_3) || $__internal_compile_3 instanceof ArrayAccess ? ($__internal_compile_3["url"] ?? null) : null), "html", null, true);
            echo "/page-";
            echo twig_escape_filter($this->env, ((($__internal_compile_4 = ($context["Pagination"] ?? null)) && is_array($__internal_compile_4) || $__internal_compile_4 instanceof ArrayAccess ? ($__internal_compile_4["len"] ?? null) : null) - 1), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, ((($__internal_compile_5 = ($context["Pagination"] ?? null)) && is_array($__internal_compile_5) || $__internal_compile_5 instanceof ArrayAccess ? ($__internal_compile_5["len"] ?? null) : null) - 1), "html", null, true);
            echo "</a></li>
    ";
        }
        // line 8
        echo "    <ul id=\"pagination\">
        ";
        // line 9
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(range(1, ((($__internal_compile_6 = ($context["Pagination"] ?? null)) && is_array($__internal_compile_6) || $__internal_compile_6 instanceof ArrayAccess ? ($__internal_compile_6["len"] ?? null) : null) - 1)));
        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
            // line 10
            echo "            ";
            if (($context["i"] >= (($__internal_compile_7 = ($context["Pagination"] ?? null)) && is_array($__internal_compile_7) || $__internal_compile_7 instanceof ArrayAccess ? ($__internal_compile_7["active"] ?? null) : null))) {
                // line 11
                echo "                <li><a class=\"";
                if (($context["i"] == (($__internal_compile_8 = ($context["Pagination"] ?? null)) && is_array($__internal_compile_8) || $__internal_compile_8 instanceof ArrayAccess ? ($__internal_compile_8["active"] ?? null) : null))) {
                    echo "active";
                }
                echo "\" href=\"";
                echo twig_escape_filter($this->env, (($__internal_compile_9 = ($context["Pagination"] ?? null)) && is_array($__internal_compile_9) || $__internal_compile_9 instanceof ArrayAccess ? ($__internal_compile_9["url"] ?? null) : null), "html", null, true);
                echo "/page-";
                echo twig_escape_filter($this->env, $context["i"], "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $context["i"], "html", null, true);
                echo "</a></li>
            ";
            }
            // line 13
            echo "        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 14
        echo "    </ul>
</div> 
";
    }

    public function getTemplateName()
    {
        return "common/pagination.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  91 => 14,  85 => 13,  71 => 11,  68 => 10,  64 => 9,  61 => 8,  51 => 6,  48 => 5,  42 => 3,  40 => 2,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "common/pagination.html", "/var/www/cartest/data/www/cartest.new/templates/common/pagination.html");
    }
}
