 <?php

use lib\Twig\Environment;
use lib\Twig\Error\LoaderError;
use lib\Twig\Error\RuntimeError;
use lib\Twig\Extension\SandboxExtension;
use lib\Twig\Markup;
use lib\Twig\Sandbox\SecurityError;
use lib\Twig\Sandbox\SecurityNotAllowedTagError;
use lib\Twig\Sandbox\SecurityNotAllowedFilterError;
use lib\Twig\Sandbox\SecurityNotAllowedFunctionError;
use lib\Twig\Source;
use lib\Twig\Template;

/* default/index.html */
class __TwigTemplate_162839853cb33f6a619d159171d76288 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'header' => [$this, 'block_header'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.html", "default/index.html", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 6
    public function block_header($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " 
   ";
        // line 7
        $this->displayParentBlock("header", $context, $blocks);
        echo "
";
    }

    // line 10
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 11
        echo "   <div class=\"gradient\">
      <div class=\"conteiner\">
         <div><h1>Comparisons, reviews, and specifications of any cars </h1></div>
         <div></div>
      </div>
   </div>
   <div class=\"conteiner\">
      
      <div class=\"about\">
         <div>
            <h2>About</h2>
            <p>";
        // line 22
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["mainPage"] ?? null), "text", [], "any", false, false, false, 22), "html", null, true);
        echo "</p>
         </div>
         <div>
            <img src=\"/img/car.webp\" alt=\"Car\">
         </div>
      </div>


      <div class=\"favoritMenu\">
         <ul>
         ";
        // line 32
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, ($context["menu"] ?? null), 1, [], "any", false, false, false, 32));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 33
            echo "            <li><a href=\"/";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["item"], "url", [], "any", false, false, false, 33), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["item"], "name", [], "any", false, false, false, 33), "html", null, true);
            echo "</a></li>
         ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 35
        echo "         </ul>
      </div>


      <div class=\"popularComparison\">
         <h2>Side-by-side car comparisons</h2>
         <ul>
               <li>
                  <a href=\"/\">
                     <img src=\"/img/car.webp\" width=\"250\" alt=\"Car\">
                     <img src=\"/img/car.webp\" width=\"250\" alt=\"Car\">
                  </a>
                  <a href=\"/\" class=\"btn\">View comparison</a>
               </li>
               <li>
                  <a href=\"/\">
                     <img src=\"/img/car.webp\" width=\"250\" alt=\"Car\">
                     <img src=\"/img/car.webp\" width=\"250\" alt=\"Car\">
                  </a>
                  <a href=\"/\" class=\"btn\">View comparison</a>
               </li>
         </ul>
      </div>

      <div class=\"popularBlog\">
         <h2>Popular Blog</h2>
         <ul>
            ";
        // line 62
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(range(1, 12));
        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
            // line 63
            echo "            <li>
               <a href=\"/\">
                  <img src=\"/img/car.webp\" width=\"100%\" alt=\"Car\">
                  <p>Title Blog ";
            // line 66
            echo twig_escape_filter($this->env, $context["i"], "html", null, true);
            echo "</p>
               </a>
            </li>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 70
        echo "         </ul>
      </div>
      
   </div>
";
    }

    public function getTemplateName()
    {
        return "default/index.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  152 => 70,  142 => 66,  137 => 63,  133 => 62,  104 => 35,  93 => 33,  89 => 32,  76 => 22,  63 => 11,  59 => 10,  53 => 7,  47 => 6,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "default/index.html", "/var/www/cartest/data/www/cartest.new/templates/default/index.html");
    }
}
